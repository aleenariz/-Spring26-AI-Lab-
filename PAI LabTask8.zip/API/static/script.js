document.addEventListener("DOMContentLoaded", function () {
    const card = document.querySelector(".card");

    if (card) {
        let tempText = card.querySelector("p b").nextSibling.textContent;
        let temp = parseFloat(tempText);

        if (temp >= 30) {
            card.style.backgroundColor = "#ff6b6b"; // hot → soft red
        } else if (temp >= 20) {
            card.style.backgroundColor = "#f6c23e"; // mild → warm yellow/orange
        } else if (temp >= 10) {
            card.style.backgroundColor = "#4da6ff"; // cool → soft blue
        } else {
            card.style.backgroundColor = "#2c3e50"; // very cold → dark blue
        }
    }
});