import requests
from flask import Flask, render_template, request
import datetime

app = Flask(__name__)

# 🔑 Yahan apni nayi API key dal do
API_KEY = "2ab854bf67fec5010c778b77803b60be"

@app.route("/", methods=["GET", "POST"])
def home():
    weather = None
    city = "Lahore"  # Default city
    if request.method == "POST":
        city = request.form.get("city")
        print(f"City entered: {city}") 

    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    print(f"Status code: {response.status_code}") 

    if response.status_code == 200:
        data = response.json()
        print(data)
    weather = {
    "city": data["name"],
    "country": data["sys"]["country"],
    "temp": data["main"]["temp"],
    "feels_like": data["main"]["feels_like"],
    "humidity": data["main"]["humidity"],
    "pressure": data["main"]["pressure"],
    "wind_speed": data["wind"]["speed"],
    "wind_deg": data["wind"]["deg"],
    "clouds": data["clouds"]["all"],
    "visibility": data.get("visibility", "N/A"),
    "sunrise": datetime.datetime.fromtimestamp(data["sys"]["sunrise"]).strftime('%H:%M'),
    "sunset": datetime.datetime.fromtimestamp(data["sys"]["sunset"]).strftime('%H:%M'),
    "description": data["weather"][0]["description"].title(),
    "icon": data["weather"][0]["icon"]
}

    return render_template("index.html", weather=weather)

if __name__ == "__main__":
    app.run(debug=True)