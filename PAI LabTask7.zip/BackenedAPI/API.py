import requests
from flask import Flask, request, jsonify
import datetime

app = Flask(__name__)

API_KEY = "2ab854bf67fec5010c778b77803b60be"

@app.route("/", methods=["GET"])
def weather_api():
    # User specifies city via URL: ?city=Islamabad
    city = request.args.get("city", "Lahore")  # default Lahore

    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    response = requests.get(url)

    if response.status_code != 200:
        return jsonify({"error": f"Could not fetch weather for '{city}'", "status_code": response.status_code})

    data = response.json()

    weather = {
        "city": data["name"],
        "country": data["sys"]["country"],
        "temp": data["main"]["temp"],
        "feels_like": data["main"]["feels_like"],
        "humidity": data["main"]["humidity"],
        "pressure": data["main"]["pressure"],
        "wind_speed": data["wind"]["speed"],
        "wind_deg": data["wind"]["deg"],
        "clouds": data["clouds"]["all"],
        "visibility": data.get("visibility", "N/A"),
        "sunrise": datetime.datetime.fromtimestamp(data["sys"]["sunrise"]).strftime('%H:%M'),
        "sunset": datetime.datetime.fromtimestamp(data["sys"]["sunset"]).strftime('%H:%M'),
        "description": data["weather"][0]["description"].title(),
        "icon": data["weather"][0]["icon"]
    }

    return jsonify(weather)

if __name__ == "__main__":
    app.run(debug=True)