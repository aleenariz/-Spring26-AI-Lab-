# 🤖 RAG Chatbot — Streamlit + Groq + LangChain

A full-stack chatbot app with two modes:
- **Simple Chat** – Chat directly with Groq LLM (LLaMA 3)
- **Chat with PDF (RAG)** – Upload any PDF and ask questions using Retrieval Augmented Generation

---

## 📁 Project Structure

```
rag-chatbot/
├── app.py                        ← Home / landing page
├── pages/
│   ├── 1_💬_Simple_Chat.py       ← Direct LLM chat
│   └── 2_📄_Chat_with_PDF.py     ← RAG with PDF upload
├── .streamlit/
│   └── config.toml               ← UI theme settings
├── requirements.txt              ← All dependencies
├── .env.example                  ← API key template
└── README.md
```

---

## ⚙️ Setup Instructions

### Step 1 — Install Python 3.11+
Make sure you have Python 3.11 or above:
```bash
python --version
```

### Step 2 — Create a virtual environment (recommended)
```bash
python -m venv venv

# Windows:
venv\Scripts\activate

# Mac/Linux:
source venv/bin/activate
```

### Step 3 — Install all dependencies
```bash
pip install -r requirements.txt
```

### Step 4 — Get your FREE Groq API Key
1. Go to: https://console.groq.com/keys
2. Sign up / Log in
3. Click **"Create API Key"**
4. Copy the key

### Step 5 — Set up your API key
Create a `.env` file in the project root:
```bash
# Windows (Command Prompt):
copy .env.example .env

# Mac/Linux:
cp .env.example .env
```

Then open `.env` and replace the placeholder:
```
GROQ_API_KEY=gsk_your_actual_key_here
```

### Step 6 — Run the app
```bash
streamlit run app.py
```

The app will open automatically at: **http://localhost:8501**

---

## 🚀 How to Use

### 💬 Simple Chat
1. Click **"Simple Chat"** in the sidebar
2. Type your question and press Enter
3. Adjust model and temperature in the sidebar settings

### 📄 Chat with PDF (RAG)
1. Click **"Chat with PDF"** in the sidebar
2. Upload any PDF using the file uploader
3. Wait for it to process (builds a vector index)
4. Ask questions about your document!

---

## 📦 Dependencies Explained

| Package | Purpose |
|---|---|
| `streamlit` | Frontend UI framework |
| `langchain` | LLM orchestration framework |
| `langchain-groq` | Groq API integration for LangChain |
| `langchain-community` | Community integrations (PDF loaders, etc.) |
| `sentence-transformers` | Local embedding model (all-MiniLM-L12-v2) |
| `pypdf` | PDF reading/parsing |
| `python-dotenv` | Load `.env` file for API keys |
| `chromadb` | Vector database for RAG |

---

## ❓ Common Issues

**"GROQ_API_KEY not found"**  
→ Make sure your `.env` file exists and has the correct key.

**PDF processing is slow**  
→ First run downloads the embedding model (~90MB). Subsequent runs are fast.

**`chromadb` install error on Windows**  
→ Run: `pip install chromadb --only-binary=:all:`

---

## 🆓 Free Tier Info
Groq offers a **completely free tier** with generous rate limits.  
No credit card required. Get your key at https://console.groq.com
