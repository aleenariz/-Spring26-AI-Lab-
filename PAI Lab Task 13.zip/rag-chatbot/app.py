import streamlit as st

st.set_page_config(
    page_title="RAG Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
    <style>
        .block-container { padding-top: 2rem; }
        .stChatMessage { border-radius: 12px; }
    </style>
""", unsafe_allow_html=True)

st.title("🤖 RAG Chatbot")
st.markdown("### Welcome! Choose a mode from the sidebar.")

col1, col2 = st.columns(2)

with col1:
    st.info("""
    **💬 Simple Chat**  
    Chat directly with Groq LLM (LLaMA 3).  
    No documents needed — just ask anything!
    """)

with col2:
    st.success("""
    **📄 Chat with PDF (RAG)**  
    Upload any PDF and ask questions about it.  
    Uses RAG (Retrieval Augmented Generation).
    """)

st.markdown("---")
st.markdown("""
**How to get started:**
1. Add your `GROQ_API_KEY` in the `.env` file (see setup instructions)
2. Navigate using the **sidebar** on the left
3. For RAG mode, upload a PDF and start chatting!
""")
